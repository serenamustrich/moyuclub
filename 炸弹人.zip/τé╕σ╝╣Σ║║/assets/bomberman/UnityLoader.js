var UnityLoader = {
    instantiate: function(containerId, buildUrl, options) {
        console.log('UnityLoader instantiate called');
        console.log('Container ID:', containerId);
        console.log('Build URL:', buildUrl);
        console.log('Options:', options);
        
        // 模拟Unity WebGL游戏加载
        var container = document.getElementById(containerId);
        var progress = 0;
        var intervalId;
        
        // 模拟加载进度
        function updateProgress() {
            progress += 0.05; // 每次增加5%的进度
            if (progress > 1) {
                progress = 1;
                clearInterval(intervalId);
                
                // 加载完成
                if (container) {
                    container.innerHTML = '<div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; color: white; font-family: Arial, sans-serif;">Bomberman WebGL Game<br><br>Game Loaded!<br><br>Use WASD to move<br>Space to place bomb<br>ESC to pause</div>';
                }
            }
            
            // 调用进度回调
            if (options && options.onProgress) {
                options.onProgress(null, progress);
            }
        }
        
        if (container) {
            container.innerHTML = '<div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; color: white; font-family: Arial, sans-serif;">Bomberman WebGL Game<br><br>Loading...</div>';
            
            // 开始模拟加载进度
            intervalId = setInterval(updateProgress, 200); // 每200毫秒更新一次进度
        }
        
        return {
            SendMessage: function(object, method, param) {
                console.log('SendMessage called:', object, method, param);
            },
            SetFullscreen: function(enabled) {
                console.log('SetFullscreen called:', enabled);
            }
        };
    }
};

function UnityProgress(gameInstance, progress) {
    console.log('UnityProgress called:', progress);
}
