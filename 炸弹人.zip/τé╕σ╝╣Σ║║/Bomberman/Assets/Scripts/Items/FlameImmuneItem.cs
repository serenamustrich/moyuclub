using UnityEngine;

public class FlameImmuneItem : Item
{
    void Start()
    {
        itemType = ItemType.FlameImmune;
    }
}