using UnityEngine;

public class PowerItem : Item
{
    void Start()
    {
        itemType = ItemType.Power;
    }
}