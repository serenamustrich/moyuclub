using UnityEngine;

public class SpeedItem : Item
{
    void Start()
    {
        itemType = ItemType.Speed;
    }
}