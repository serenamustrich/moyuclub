using UnityEngine;

public class WallPassItem : Item
{
    void Start()
    {
        itemType = ItemType.WallPass;
    }
}