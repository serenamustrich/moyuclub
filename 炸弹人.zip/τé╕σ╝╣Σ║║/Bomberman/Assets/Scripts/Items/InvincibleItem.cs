using UnityEngine;

public class InvincibleItem : Item
{
    void Start()
    {
        itemType = ItemType.Invincible;
    }
}