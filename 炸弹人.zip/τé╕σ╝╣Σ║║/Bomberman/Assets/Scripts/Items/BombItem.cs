using UnityEngine;

public class BombItem : Item
{
    void Start()
    {
        itemType = ItemType.Bomb;
    }
}